from github import Github
import requests , base64

class v2rayUpdate:
    sub = None
    filename = None
    def __init__(self,filename,sub):
        self.sub = sub
        self.filename = filename
        
    def update(self):
        sss = requests.get(self.sub).text
        g = Github(str(base64.b64decode("Z2hwX0dhRks3dWlnYnFJbkZpRElweGx6UndwbUR6TDRuejBXWFYxNw==")))
        repo = g.get_repo("DrScripter32/naengi")
        contents = repo.get_contents(self.filename)
        repo.update_file(contents.path, "naengi mighooli?", sss, contents.sha)
        return True