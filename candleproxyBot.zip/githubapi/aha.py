import GVU

vmessurl="https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/splitted/vmess.txt"

updater = GVU.v2rayUpdate(vmessurl)

updater.updateVmess()
