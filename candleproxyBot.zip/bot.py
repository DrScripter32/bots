from pyrogram import Client ,enums
import string , random , asyncio
from bs4 import BeautifulSoup
from github import Github
import sqlite3
import hashlib
from json import load , dumps
import requests
from pyrogram.types import ReplyKeyboardMarkup,InlineKeyboardButton,InlineKeyboardMarkup
from githubapi import GVU
def newToken(chat_id):
	ci = str(chat_id)+"نائنگی"+str(chat_id)
	hash = hashlib.sha256((ci.encode())).hexdigest()
	return str(hash)

def getRandomString():
    s = string.ascii_lowercase
    return ( ''.join(random.choice(s) for i in range(random.randint(8,18))) ) + str(random.randint(0,999))

async def v2free():
    url = "https://w1.v2free.top"
    regUrl = "/auth/register"
    userUrl = "/user"

    headers = {
        "X-Requested-With":"XMLHttpRequest",
        "Referer":"https://w1.v2free.top/auth/register"
    }
    data = {

        "email":getRandomString()+"@gmail.com",
        "name":"",
        "country":"CN",
        "passwd":"12345678",
        "repasswd":"12345678",
        "wechat":"",
        "imtype":"4",
        "code":"0"
    }
    res = requests.post(url+regUrl,headers=headers,data=data)
    cooc = {
        "uid":res.cookies["uid"],
        "email":res.cookies["email"],
        "key":res.cookies["key"],
        "ip":res.cookies["ip"],
        "expire_in":res.cookies["expire_in"]
    }
    headers = {
        "Referer":"https://w1.v2free.top/auth/register"
    }
    res2 = requests.get(url+userUrl,cookies=cooc,headers=headers)
    soup = BeautifulSoup(res2.text, 'html.parser')
    ass = soup.find_all("a", {"class": "copy-text btn-dl"})

    js = {"description":getRandomString(),"sections":[{"name":getRandomString(),"syntax":"autodetect","contents":requests.get(str(ass[0]["data-clipboard-text"])).text}]}
    h = {"X-Auth-Token":"awZGgjov5jgY2E8PZfqfkSkcObhyY4vI0E6GfhJEm"}
    return "https://paste.ee/d/"+requests.post("https://api.paste.ee/v1/pastes",json=js,headers=h).json()["id"]


con = sqlite3.connect('database.db')
c = con.cursor()
c.execute("""CREATE TABLE IF NOT EXISTS users(
   ID INTEGER PRIMARY KEY AUTOINCREMENT,
   userid TEXT,
   input TEXT,
   info TEXT,
   token TEXT,
   verify TEXT,
   phone TEXT);
""")
con.commit()
def webProxy1(url):
   baseURL="https://proxyium.com/proxyrequest"
   res=requests.post(baseURL,data={"url":url})
def get_users_list():
   a = c.execute(f'SELECT  userid FROM users').fetchall()
   list=[]
   for i in a:
      list.append(i[0])
   return list
def getMtp(num):
   data = load(open("mtps.json"))["mtps"]
   data.reverse()
   return data
def writeMtp(mtp):
   json = load(open("mtps.json"))
   json["mtps"].append(mtp)
   open("mtps.json","w").write(dumps(json))

def writeV2ray(v2):
   json = load(open("v2ray.json"))
   json["servers"].append(v2)
   open("v2ray.json","w").write(dumps(json))

def check_user_exists(chatid):
    if (c.execute(f'SELECT  * FROM users WHERE userid="{chatid}"')).fetchone():
        return True
    return False
def get_value_db(a,b):
    return c.execute(f'SELECT {a} FROM users WHERE userid="{b}"').fetchall()
def update_value_db(a,value,b):
    c.execute(f'UPDATE users SET "{a}"="{value}" WHERE userid="{b}"')
    con.commit()

def telSubUpdater():
   lim=0
   st=""
   servers = load(open("v2ray.json"))['servers']
   for i in servers:
      lim +=1
      if lim == 50:
         break
      st=st+i+"\n"
   g = Github("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")
   repo = g.get_repo("DrScripter32/naengi")
   contents = repo.get_contents("telMixed.txt")
   repo.update_file(contents.path, "naengi mighooli?", st, contents.sha)

admins=["5358806899"]
tkn="5888419666:AAFpKJoZdENHDTmqRP0D20EMhdhbAAPJxw4"
ah="b911e7836be5cbdc8688fa3d1269d377"
ai=9808879
app = Client("accbot",api_hash=ah,api_id=ai,bot_token=tkn)
print('ok')
startText="""**
خوش آمدید : ) 

1⃣ کانفیگ های ربات هر چند ساعت یکبار اپدیت میشن ،جهت دسترسی راحت تر بصورت لینک ساب به کاربر داده میشه (آموزش استفاده قرار داده شده)⚠️

2⃣ پروکسی های تگلرام هر چند ساعت اپدیت میشه⚜⚠️

3⃣ اگه کانفیگ یا پروکسی پرسرعتی تشخیص داده بشه به صورت خودکار واستون ارسال میشه⚠️

⚠️ از بخش vpn میتونید وارد چنل ربات شید ، وی‌پی‌ان های پرسرعت و کانفیگ ها بصورت فایل گذاشته میشه ⚠️
**"""
k1Text="""
لینک های ساب شما :
(روی هرکدام کلیک کنید کپی میشه)
`https://raw.githubusercontent.com/DrScripter32/naengi/main/vmess.txt`
➖➖➖➖➖➖
`https://raw.githubusercontent.com/DrScripter32/naengi/main/telMixed.txt`
نکته:
تمامی کانفیگ های لینک اول از منابع رایگان دنیا جمع اوری میشود.
تمامی کانفیگ های لینک دوم از کانال های تلگرام جمع اوری میشود.
"""
webpText="""
*این بخش میتونه لینک‌هایی مانند لینک یک ویدیو در یوتیوب یا لینک سایت‌های فیلتر رو بگیره و لینک جدیدی بدون فیلتر بهتون بده تا بتونید به راحتی اون ویدیو رو ببینید. ❤️‍🩹*

"""
supportText="""
سوالات و انتقاد هرچی داری همینجا بفرست واسه ادمین فوروارد میکنم🫡
یا جوین گروه شو :
https://t.me/+_QGIcPnKDkI4ZDQ8

لغو با کلیک روی (بازگشت)
"""
dText="""
میتونید با ارسال مقدار دلخواه ارز دیجیتال:
USDT :
`0x1a6B90A5d1A7a0E046B7C53c3230115A994df534`
ETH :
`0x1a6B90A5d1A7a0E046B7C53c3230115A994df534`
TRX :
`TASddSFuE33e1EYqWveru1hQwTDeC6bpiH`
DGB :
`dgb1qfsh3ar7l36pu7e78vrd0q3lkdjhnjepaaz4j8e`

یا با ارسال سرور مجازی ، پروکسی و کانفیگ در بخش پشتیبانی از ما حمایت کنید ❤️‍🩹
"""
vpnChLink="https://t.me/naengiPlus"
vmessurl="https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/splitted/vmess.txt"
vmessUpdater = GVU.v2rayUpdate("vmess.txt",vmessurl)
k1Inline=InlineKeyboardMarkup([[
                        InlineKeyboardButton("▫️برنامه مورد نیاز ▫️", url='https://t.me/amoozesh_boghol/36'),
                        InlineKeyboardButton("▫️آموزش استفاده▫️", url='https://t.me/naengiPlus/6',)]])

k0="⬅️ بازگشت ⬅️";k1="🖱 کانفیگ v2ray 🖱";k2="🌐 پروکسی تلگرام 🌐";k3="💢  V P N  💢";k4="📱 وب پروکسی 📱";k5="❤️‍🩹 حمایت از ما ❤️‍🩹";k6="👤 پشتیبانی 👤"
startKey= ReplyKeyboardMarkup([[k1],[k2],[k3],[k5,k6]],resize_keyboard=True,one_time_keyboard=False)
backKey = ReplyKeyboardMarkup([[k0]],resize_keyboard=True,one_time_keyboard=False)
k1r = ReplyKeyboardMarkup([["🌐دریافت لینک ساب🌐"],["💢method-1💢"],[k0]],resize_keyboard=True,one_time_keyboard=False)
@app.on_message()
async def main(client,message):
    ci=message.chat.id
    pm=message.text

    if pm =="/start":
        if check_user_exists(ci)==False:
         c.execute(f"""INSERT INTO users(userid, input, info, token, verify, phone ) 
   VALUES('{ci}', '0','0','{newToken(ci)}','false','0');""")
         con.commit()
         await app.send_chat_action(ci,enums.chat_action.ChatAction.TYPING)
         await app.send_message(chat_id=ci,text=startText,reply_markup=startKey)
        else:
         await app.send_chat_action(ci,enums.chat_action.ChatAction.TYPING)
         await app.send_message(chat_id=ci,text=startText,reply_markup=startKey)
         update_value_db("input","0",str(ci))
    elif pm ==k0:
      #await app.forward_messages(5358806899,ci,message_ids=message.id)
      update_value_db("input","0",str(ci))
      await app.send_message(ci,"🏠",reply_markup=startKey)

    elif get_value_db("input",str(ci))[0][0] == "getLink":
       await app.send_chat_action(ci,enums.chat_action.ChatAction.TYPING)
       res = webProxy1(pm)
       if "http" in res:
          await app.send_message(ci,"""**⚠️از این لینک فقط یک نفر میتواند استفاده کند.
برای  مشاهده روی دکمه زیر کلیک کنید.**""",reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("proxy-1",url=res[0])]]))
       else:
          await app.send_message(ci,"خطا")
    elif get_value_db("input",str(ci))[0][0] == "pms":
       update_value_db("input","0",str(ci))
       await app.send_message(ci,"sending . . . ")
       users=get_users_list()
       for i in users:
          await app.copy_message(chat_id=int(i),message_ids=message.id,from_chat_id=ci)
       await app.send_message(ci,"finish !")
          
    elif get_value_db("input",str(ci))[0][0] == "support":
       update_value_db("input","0",str(ci))
       for i in admins:
         await app.forward_messages(int(i),ci,message.id)
         await app.send_message(i,"user : `"+str(ci)+"`")
       await app.send_message(ci,"به پشتیبانی ارسال شد 🫡✅",reply_to_message_id=message.id,reply_markup=backKey)
    elif pm == k1:
       await app.send_message(ci,"متود را انتخاب کنید",reply_to_message_id=message.id,reply_markup=k1r)
    elif pm == "🌐دریافت لینک ساب🌐":
      await app.send_message(chat_id=ci,text=k1Text,reply_markup=k1Inline)
    elif pm == "💢method-1💢" or pm == "/rm1":
       await app.send_message(ci,"🔄درحال پردازش🔄")
       try:
          await app.send_message(ci,"`"+str(await v2free())+"`")
          await app.send_message(ci,"""
          کانفیگ های شما ساخته شد
          توجه داشنه باشید کانفیگ ها بعد از چند دقیقه فعال میشوند
          حجم کانفیگ ها 1 گیگابایت میباشد
          در صورت اتمام حجم مجدد به این بخش بیاید یا دستور /rm1 را وارد کنید

          """)
       except Exception as e:
          await app.send_message(ci,"خطایی رخ داد مجدد امتحان کنید💔")
          await app.send_message(ci, e)
    elif pm == k2:
      await app.send_chat_action(ci,enums.chat_action.ChatAction.TYPING)
      mtps=getMtp(0)
      await app.send_message(ci,"🌐 پروکسی ها هرروز اپدیت میشوند 🌐",reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("پروکسی اول",url=mtps[0]),InlineKeyboardButton("پروکسی دوم",url=mtps[1])],
                                                                             [InlineKeyboardButton("پروکسی سوم",url=mtps[2]),InlineKeyboardButton("پروکسی چهارم",url=mtps[3])],[
                                                                             InlineKeyboardButton("پروکسی پنجم",url=mtps[4]),InlineKeyboardButton("پروکسی ششم",url=mtps[5])]]))
    elif pm == k3:
      await app.send_message(ci,"📱وی پی ان های اندروید در کانال زیر قرار میگیرند📱",reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("💢 لینک کانال 💢",url=vpnChLink)]]))
    elif pm == k4:
      await app.send_message(ci,webpText,reply_markup=backKey)
      update_value_db("input","getLink",str(ci))
    elif pm == k5:
      await app.send_message(ci,dText)
    elif pm == k6:
      await app.send_message(ci,supportText,reply_markup=backKey)
      update_value_db("input","support",str(ci))
    elif pm == "/admin" and str(ci) in admins:
       await app.send_message(ci,"left bede")
    elif pm == "/updateSub" and str(ci) in admins:
       await app.send_message(ci,"updating . . .")
       try:
         vmessUpdater.update()
         await app.send_message(ci,"**hale **")
       except Exception as e:
         await app.send_message(ci,e)
    elif pm == "/updateTelSub" and str(ci) in admins:
       await app.send_message(ci,"**updating ... **")
       try:
         telSubUpdater()
         await app.send_message(ci,"**hale **")
       except Exception as e:
         await app.send_message(ci, e)
    elif "vmess://" in pm and str(ci) in admins:
       writeV2ray(pm)
       await app.send_message(ci,"با موفقیت دزدیده شد🫡")
    elif "vless://" in pm and str(ci) in admins:
       writeV2ray(pm)
       await app.send_message(ci,"با موفقیت دزدیده شد🫡")
    elif "ss://" in pm and str(ci) in admins:
       writeV2ray(pm)
       await app.send_message(ci,"با موفقیت دزدیده شد🫡")
    elif "ssr://" in pm and str(ci) in admins:
       writeV2ray(pm)
       await app.send_message(ci,"با موفقیت دزدیده شد🫡")
    elif "https://t.me/proxy?" in pm and str(ci) in admins:
       writeMtp(pm)
       await app.send_message(ci,"با موفقیت دزدیده شد🫡")
    elif "/pms" in pm and str(ci) in admins:
       await app.send_message(ci,"bashe , payameto ersal kon :| \n cancel : /start")
       update_value_db("input","pms",str(ci))
    elif "!send" in pm and str(ci) in admins:
       cii = pm.split(".")[1]
       tosend = pm.split(".")[2]
       await app.send_message(int(cii),tosend)
       await app.send_message(ci,"ok . !")


app.run()