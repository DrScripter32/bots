import requests

he = {
    "Alt-Used":"proxyium.com",
    "Origin":"https://proxyium.com",
    "Referer":"https://proxyium.com/",
    "Sec-Fetch-Dest":"document",
    "Sec-Fetch-Mode":"navigate",
    "Sec-Fetch-Site":"same-origin",
    "Sec-Fetch-User":"?1",
    "Upgrade-Insecure-Requests":"1"

}
res = requests.post("https://proxyium.com/proxyrequest",headers=he,data={"url":"google.com"})

print(res.headers)

print(res.text)