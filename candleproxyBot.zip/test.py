import requests , string , random
from bs4 import BeautifulSoup

def getRandomString():
    s = string.ascii_lowercase
    return ( ''.join(random.choice(s) for i in range(random.randint(8,18))) ) + str(random.randint(0,999))

def v2free():
    url = "https://w1.v2free.top"
    regUrl = "/auth/register"
    userUrl = "/user"

    headers = {
        "X-Requested-With":"XMLHttpRequest",
        "Referer":"https://w1.v2free.top/auth/register"
    }
    data = {

        "email":getRandomString()+"@gmail.com",
        "name":"",
        "country":"CN",
        "passwd":"12345678",
        "repasswd":"12345678",
        "wechat":"",
        "imtype":"4",
        "code":"0"
    }
    res = requests.post(url+regUrl,headers=headers,data=data)
    cooc = {
        "uid":res.cookies["uid"],
        "email":res.cookies["email"],
        "key":res.cookies["key"],
        "ip":res.cookies["ip"],
        "expire_in":res.cookies["expire_in"]
    }
    headers = {
        "Referer":"https://w1.v2free.top/auth/register"
    }
    res2 = requests.get(url+userUrl,cookies=cooc,headers=headers)
    soup = BeautifulSoup(res2.text, 'html.parser')
    ass = soup.find_all("a", {"class": "copy-text btn-dl"})

    js = {"description":getRandomString(),"sections":[{"name":getRandomString(),"syntax":"autodetect","contents":requests.get(str(ass[0]["data-clipboard-text"])).text}]}
    h = {"X-Auth-Token":"awZGgjov5jgY2E8PZfqfkSkcObhyY4vI0E6GfhJEm"}
    return "https://paste.ee/d/"+requests.post("https://api.paste.ee/v1/pastes",json=js,headers=h).json()["id"]


