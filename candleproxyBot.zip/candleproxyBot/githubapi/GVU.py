from github import Github
import requests

class v2rayUpdate:
    sub = None
    filename = None
    def __init__(self,filename,sub):
        self.sub = sub
        self.filename = filename
        
    def update(self):
        sss = requests.get(self.sub).text
        g = Github("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")
        repo = g.get_repo("DrScripter32/naengi")
        contents = repo.get_contents(self.filename)
        repo.update_file(contents.path, "naengi mighooli?", sss, contents.sha)
        return True